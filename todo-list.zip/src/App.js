import React, { useState, useEffect } from 'react'
import axios from 'axios'
const App = () => {
  const [myData, setData] = useState([])
  const [search, setSearch] = useState('')
  const [searchData, setSearchData] = useState([])

  console.log(myData)

  useEffect(() => {
    axios
      .get('https://jsonplaceholder.typicode.com/todos')
      .then((res) => setData(res.data))
  }, [])

  useEffect(() => {
    setSearchData(
      myData.filter((item, index) => {
        return item.title.includes(search)
      })
    )
  }, [search, myData])

  return (
    <>
      <p>
        {searchData.reduce((initial, item) => {
          return !item.completed ? initial + 1 : initial
        }, 0)}
      </p>
      <input
        type='search'
        placeholder='search'
        onChange={(e) => {
          setSearch(e.target.value)
        }}
      ></input>
      {searchData.map((item, index) => {
        return (
          <div
            style={{ display: 'flex', justifyContent: 'space-between' }}
            key={index}
          >
            <p
              key={index}
              className={item.completed ? 'green' : 'red'}
              style={{ width: '60vw' }}
            >
              {item.title}
            </p>
            <button
              onClick={() => {
                const myIndex = myData.indexOf(item)
                setData((prev) => {
                  const temp = [...prev]
                  temp.splice(myIndex, 1)
                  return [...temp]
                })
              }}
            >
              delete
            </button>
            <button
              style={{ backgroundColor: item.completed ? 'red' : ' green' }}
              onClick={() => {
                const status = item.completed
                const myIndex = myData.indexOf(item)
                setData((last) => {
                  const temp = [...last]
                  temp[myIndex].completed = !status
                  return temp
                })
              }}
            >
              {item.completed ? 'deactive' : 'active'}
            </button>
          </div>
        )
      })}
    </>
  )
}

export default App
